package au.gov.csc.prod.api.experience.defense.exchange;

import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import static au.gov.csc.prod.api.experience.defense.exchange.status.StatusFactory.createStatus;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status;


public abstract class AbstractNotificationStatus implements NotificationStatus {
    private final Status status;

    public AbstractNotificationStatus(final Status status) {
        this.status = status;

    }

    @Override
    public abstract void transition();



}
