package au.gov.csc.prod.api.experience.defense.exchange;

import au.gov.csc.prod.api.experience.defense.exchange.exception.InvalidInputException;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(name = "CDEX", serviceName = "CDEX_SERVICE", portName = "CDEX_PORT", targetNamespace = "http://exchange/defence/experience/api/prod.csc.gov.au" )
public interface CDEX {
    @WebMethod(operationName = "notify", action = "notify")
    @WebResult(name = "Response")
    NotificationResponse notify(@WebParam(name = "message") final NotificationMessage notificationMessage)throws InvalidInputException;
}
