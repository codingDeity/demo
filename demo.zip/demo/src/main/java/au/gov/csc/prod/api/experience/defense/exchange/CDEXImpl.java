package au.gov.csc.prod.api.experience.defense.exchange;



import au.gov.csc.prod.api.experience.defense.exchange.status.StatusFactory;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService(endpointInterface = "au.gov.csc.prod.api.experience.defense.exchange.CDEX", serviceName = "CDEX_SERVICE", portName = "CDEX_PORT")
public class CDEXImpl implements CDEX {
    public CDEXImpl() {
    }


    @Override
    public NotificationResponse notify(final NotificationMessage notificationMessage) {
        // validate input otherwise throw InvalidInputException
        NotificationStatus status = StatusFactory.createStatus(notificationMessage.getNotificationStatus());

        // process notificationMessage
        return new NotificationResponse();
    }

}
