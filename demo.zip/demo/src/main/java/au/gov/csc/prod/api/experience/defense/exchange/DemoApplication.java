package au.gov.csc.prod.api.experience.defense.exchange;

import au.gov.csc.prod.api.experience.defense.exchange.status.StatusFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import javax.xml.ws.Endpoint;

@ComponentScan(basePackages = {"com.example.demo.webservice"})
@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoApplication.class, args);
		CDEX cdex = new CDEXImpl();
		Endpoint.publish(
				"http://localhost:8083/employeeservicetopdown",
				cdex);

	//	NotificationStatus status = StatusFactory.createStatus(StatusType.Status.Completed);

	}

}
