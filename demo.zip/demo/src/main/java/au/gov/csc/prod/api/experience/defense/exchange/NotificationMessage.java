package au.gov.csc.prod.api.experience.defense.exchange;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement(name = "Notification_Message")
public class NotificationMessage {
    private String notificationId;
    private String agencyId;
    private StatusType.Status  notificationStatus;
    private String rmsId;
    private String advice;

    public NotificationMessage() {
    }

    public NotificationMessage(final String notificationId, final String agencyId, StatusType.Status  notificationStatus, final String rmsId, final String advice) {
        this.notificationId = notificationId;
        this.agencyId = agencyId;
        this.notificationStatus = notificationStatus;
        this.rmsId = rmsId;
        this.advice = advice;
    }

    @XmlElement(name = "notification_id", nillable = false, required = true)
    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(final String notificationId) {
        this.notificationId = notificationId;
    }

    @XmlElement(name = "agency_id", nillable = false, required = true)
    public String getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(final String agencyId) {
        this.agencyId = agencyId;
    }

    @XmlElement(name = "notification_status", nillable = false, required = true)
    public StatusType.Status  getNotificationStatus() {
        return notificationStatus;
    }

    public void setNotificationStatus(StatusType.Status  notificationStatus) {
        this.notificationStatus = notificationStatus;
    }

    @XmlElement(name = "rms_id", nillable = false, required = true)
    public String getRmsId() {
        return rmsId;
    }

    public void setRmsId(final String rmsId) {
        this.rmsId = rmsId;
    }

    @XmlElement(name = "advice", nillable = false, required = true)
    public String getAdvice() {
        return advice;
    }

    public void setAdvice(final String advice) {
        this.advice = advice;
    }

    @Override
    public boolean equals(Object otherNotificationMessage) {
        if (this == otherNotificationMessage) {
            return true;
        }
        if (otherNotificationMessage == null || getClass() != otherNotificationMessage.getClass()) {
            return false;
        }
        NotificationMessage that = (NotificationMessage) otherNotificationMessage;
        return notificationId.equals(that.notificationId) &&
                agencyId.equals(that.agencyId) &&
                notificationStatus.equals(that.notificationStatus) &&
                rmsId.equals(that.rmsId) &&
                advice.equals(that.advice);
    }

    @Override
    public int hashCode() {
        return Objects.hash(notificationId, agencyId, notificationStatus, rmsId, advice);
    }

    @Override
    public String toString() {
        return "NotificationMessage{" +
                "notificationId='" + notificationId + '\'' +
                ", agencyId='" + agencyId + '\'' +
                ", rmsId='" + rmsId + '\'' +
                ", advice='" + advice + '\'' +
                '}';
    }
}
