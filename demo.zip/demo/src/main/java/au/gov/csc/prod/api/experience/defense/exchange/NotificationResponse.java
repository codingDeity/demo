package au.gov.csc.prod.api.experience.defense.exchange;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Objects;

@XmlRootElement(name = "Notification_Response")
public class NotificationResponse {
    private String notificationId;
    private boolean acknowledged;
    private String reason;

    public NotificationResponse() {
    }

    public NotificationResponse(final String notificationId, final boolean acknowledged, final String reason) {
        this.notificationId = notificationId;
        this.acknowledged = acknowledged;
        this.reason = reason;
    }

    @XmlElement(name = "notification_id", nillable = false, required = true)
    public String getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(final String notificationId) {
        this.notificationId = notificationId;
    }

    @XmlElement(name = "acknowledged", nillable = false, required = true)
    public boolean isAcknowledged() {
        return acknowledged;
    }

    public void setAcknowledged(final boolean acknowledged) {
        this.acknowledged = acknowledged;
    }

    @XmlElement(name = "reason", nillable = false, required = true)
    public String getReason() {
        return reason;
    }

    public void setReason(final String reason) {
        this.reason = reason;
    }

    @Override
    public boolean equals(Object otherNotificationResponse) {
        if (this == otherNotificationResponse) {
            return true;
        }
        if (otherNotificationResponse == null || getClass() != otherNotificationResponse.getClass()) {
            return false;
        }
        NotificationResponse that = (NotificationResponse) otherNotificationResponse;
        return acknowledged == that.acknowledged &&
                notificationId.equals(that.notificationId) &&
                reason.equals(that.reason);
    }

    @Override
    public int hashCode() {
        return Objects.hash(notificationId, acknowledged, reason);
    }

    @Override
    public String toString() {
        return "NotificationResponse{" +
                "notificationId='" + notificationId + '\'' +
                ", acknowledged=" + acknowledged +
                ", reason='" + reason + '\'' +
                '}';
    }
}
