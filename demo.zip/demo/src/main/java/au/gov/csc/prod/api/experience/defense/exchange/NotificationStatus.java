package au.gov.csc.prod.api.experience.defense.exchange;

public interface NotificationStatus {
    void transition();
}
