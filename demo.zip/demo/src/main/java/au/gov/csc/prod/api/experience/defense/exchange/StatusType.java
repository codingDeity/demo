package au.gov.csc.prod.api.experience.defense.exchange;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "status_type")
@XmlEnum
public class StatusType {

   public enum Status {
        Cancelled("Cancelled"),
        Closed("Closed"),
        Completed("Completed"),
        Duplicate("Duplicate"),
        Initiated("Initiated"),
        InProgress("InProgress"),
        Paused("Paused"),
        Rejected("Rejected"),
        RequestForFurtherInformation("RequestForFurtherInformation"),
        Validated("Validated");

        Status(String statusValue) {

        }

    }
}