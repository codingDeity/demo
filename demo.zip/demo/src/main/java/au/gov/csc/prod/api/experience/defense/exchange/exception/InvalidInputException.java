package au.gov.csc.prod.api.experience.defense.exchange.exception;

public class InvalidInputException extends Exception {

    private final String reason;

    public InvalidInputException(String message, String reason){
        super(message);
        this.reason = reason;
    }
}
