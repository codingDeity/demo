package au.gov.csc.prod.api.experience.defense.exchange.status;

import au.gov.csc.prod.api.experience.defense.exchange.AbstractNotificationStatus;

import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.*;

class Cancelled extends AbstractNotificationStatus {

     Cancelled(Status status) {
        super(status);
    }

    @Override
    public void transition() {

    }

    @Override
    public String toString() {
        return "Cancelled{}";
    }
}
