package au.gov.csc.prod.api.experience.defense.exchange.status;

import au.gov.csc.prod.api.experience.defense.exchange.AbstractNotificationStatus;
import au.gov.csc.prod.api.experience.defense.exchange.StatusType;

class Duplicate extends AbstractNotificationStatus {
      Duplicate(StatusType.Status status) {
        super(status);
    }

    @Override
    public void transition() {

    }


}
