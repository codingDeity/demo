package au.gov.csc.prod.api.experience.defense.exchange.status;

import au.gov.csc.prod.api.experience.defense.exchange.AbstractNotificationStatus;
import au.gov.csc.prod.api.experience.defense.exchange.StatusType;

class Initiated extends AbstractNotificationStatus {
     Initiated(StatusType.Status status) {
        super(status);
    }

    @Override
    public void transition() {

    }


}
