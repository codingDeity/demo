package au.gov.csc.prod.api.experience.defense.exchange.status;

import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status;
class MakeStatuses {

    static Cancelled createCancelled(Status status) {
        return new Cancelled(status);
    }

    static Closed createClosed(Status status) {
        return new Closed(status);
    }

    static Completed createCompleted(Status status) {
        return new Completed(status);
    }

    static Duplicate createDuplicate(Status status) {
        return new Duplicate(status);
    }

    static Initiated createInitiated(Status status) {
        return new Initiated(status);
    }

    static InProgress createInProgress(Status status) {
        return new InProgress(status);
    }

    static Paused createPaused(Status status) {
        return new Paused(status);
    }

    static Rejected createRejected(Status status) {
        return new Rejected(status);
    }

    static RequestForFurtherInformation createRequestForFurtherInformation(Status status) {
        return new RequestForFurtherInformation(status);
    }

    static Validated createValidated(Status status) {
        return new Validated(status);
    }
}
