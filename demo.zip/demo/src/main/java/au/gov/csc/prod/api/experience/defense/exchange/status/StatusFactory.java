package au.gov.csc.prod.api.experience.defense.exchange.status;

import au.gov.csc.prod.api.experience.defense.exchange.AbstractNotificationStatus;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.Cancelled;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.Closed;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.Completed;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.Duplicate;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.InProgress;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.Initiated;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.Paused;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.Rejected;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.RequestForFurtherInformation;
import static au.gov.csc.prod.api.experience.defense.exchange.StatusType.Status.Validated;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createCancelled;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createClosed;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createCompleted;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createDuplicate;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createInProgress;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createInitiated;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createPaused;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createRejected;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createRequestForFurtherInformation;
import static au.gov.csc.prod.api.experience.defense.exchange.status.MakeStatuses.createValidated;

public class StatusFactory {
    public static AbstractNotificationStatus createStatus(final Status status) {

        final AbstractNotificationStatus notificationStatus;
        switch (status) {
            case Cancelled:
                notificationStatus = createCancelled(status);
                break;
            case Closed:
                notificationStatus = createClosed(status);
                break;
            case Completed:
                notificationStatus = createCompleted(status);
                break;
            case Duplicate:
                notificationStatus = createDuplicate(status);
                break;
            case Initiated:
                notificationStatus = createInitiated(status);
                break;
            case InProgress:
                notificationStatus = createInProgress(status);
                break;
            case Paused:
                notificationStatus = createPaused(status);
                break;
            case Rejected:
                notificationStatus = createRejected(status);
                break;
            case RequestForFurtherInformation:
                notificationStatus = createRequestForFurtherInformation(status);
                break;
            case Validated:
                notificationStatus = createValidated(status);
                break;
            default:
                throw new IllegalArgumentException("status: " + status + " is not valid");
        }

        return notificationStatus;
    }
}
